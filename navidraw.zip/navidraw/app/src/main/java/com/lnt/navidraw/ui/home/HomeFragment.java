package com.lnt.navidraw.ui.home;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import com.lnt.navidraw.R;

public class HomeFragment extends Fragment {
    SharedPreferences sharedpreferences;
    EditText name;
    EditText email;
    public static final String mypreference= "mypref";
    public static final String Name= "nameKey";
    public static final String Email= "emailKey";
    private HomeViewModel homeViewModel;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        homeViewModel =
                ViewModelProviders.of(this).get(HomeViewModel.class);
        View root = inflater.inflate(R.layout.fragment_home, container, false);
        final TextView textView = root.findViewById(R.id.text_home);
        homeViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText(s);
            }
        });
        return root;
    }
    public void Get (View view){
    name = (EditText) getView().findViewById(R.id.name);
    email = (EditText) getView().findViewById(R.id.emailid);
    sharedpreferences = getActivity().getSharedPreferences(mypreference, Context.MODE_PRIVATE);
       if (sharedpreferences.contains(Name)){
        name.setText(sharedpreferences.getString(Name,""));
    }
       if(sharedpreferences.contains(Email)){
        email.setText(sharedpreferences.getString(Email,""));
    }}

    public void Clear(View view){
        name = (EditText) getView().findViewById(R.id.name);
        email = (EditText) getView().findViewById(R.id.emailid);
        name.setText("");
        email.setText("");
    }
    public void save (View view){
        String n= name.getText().toString();
        String e= email.getText().toString();

        SharedPreferences.Editor editor= sharedpreferences.edit();
        editor.putString(Name,n);
        editor.putString(Email,e);
        editor.commit();
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState){
        super.onViewCreated(view, savedInstanceState);
        //final NavController navController = Navigation.findNavController(view);
        Button btn = view.findViewById(R.id.nextbutton);
        btn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                NavController navController = Navigation.findNavController(v);
                navController.navigate(R.id.action_nav_home_to_notification);
            }
        });
        Button btn1 = view.findViewById(R.id.savebutton);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String n= name.getText().toString();
                String e= email.getText().toString();

                SharedPreferences.Editor editor= sharedpreferences.edit();
                editor.putString(Name,n);
                editor.putString(Email,e);
                editor.commit();
            }
        });
        Button btn2 = view.findViewById(R.id.retrievebutton);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                name = (EditText) getView().findViewById(R.id.name);
                email = (EditText) getView().findViewById(R.id.emailid);
                sharedpreferences = getActivity().getSharedPreferences(mypreference, Context.MODE_PRIVATE);
                if (sharedpreferences.contains(Name)){
                    name.setText(sharedpreferences.getString(Name,""));
                }
                if(sharedpreferences.contains(Email)){
                    email.setText(sharedpreferences.getString(Email,""));
                }
            }
        });
        Button btn3 = view.findViewById(R.id.clearbutton);
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                name = (EditText) getView().findViewById(R.id.name);
                email = (EditText) getView().findViewById(R.id.emailid);
                name.setText("");
                email.setText("");
            }
        });
    }}


